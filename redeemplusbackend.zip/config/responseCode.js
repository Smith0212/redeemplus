const CODES = {
    
    OPERATION_FAILED: 0,
    SUCCESS: 1,
    UNAUTHORIZED: 2,
    INACTIVE_CODE: 3,
    EMAIL_UNVERIFIED: 5,
    SEND_EMAIL_FAILED: 11,
    //...
}

module.exports = CODES;
